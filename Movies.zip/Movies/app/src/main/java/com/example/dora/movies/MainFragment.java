package com.example.dora.movies;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Movie;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;


public class MainFragment extends Fragment {


    private GridView mGridView;
    private GridViewAdapter mGridAdapter;
    static ArrayList<String> posters;
    static ArrayList<String> poster_title;
    static ArrayList<String> release_date;
    static ArrayList<String> vote_average;
    static ArrayList<String> overView;
    static ArrayList<String> MovieId;
    static ArrayList<Integer> columID;
    SharedPreferences sharedPreferences;
    DBHelper dbHelper;
    private TextView progressTV;
    private ProgressBar progressBar;
    private LinearLayout progressLayout;
    String Mostpop = "https://api.themoviedb.org/3/movie/popular?api_key=b0797d851c197292e1fb93002bcff3c1";
    String TopRate = "https://api.themoviedb.org/3/movie/top_rated?api_key=b0797d851c197292e1fb93002bcff3c1";


    public MainFragment() {
        setHasOptionsMenu(true);
        posters = new ArrayList<String>();
        poster_title = new ArrayList<String>();
        release_date = new ArrayList<String>();
        vote_average = new ArrayList<String>();
        overView = new ArrayList<String>();
        MovieId = new ArrayList<String>();
        columID = new ArrayList<Integer>();
        dbHelper = new DBHelper(this.getActivity());

    }

    String selection;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setHasOptionsMenu(true);
        sharedPreferences = getActivity().getSharedPreferences("myselection", Context.MODE_PRIVATE);
        selection = sharedPreferences.getString("selection", "popular");

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.main, menu);
        MenuItem action_sort_by_popularity = menu.findItem(R.id.sort_by_most_popular_id);
        MenuItem action_sort_by_rating = menu.findItem(R.id.sort_by_most_popular_id);
        MenuItem action_favorite = menu.findItem(R.id.favorite_item_id);

    }

    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.sort_by_most_popular_id) {
            SharedPreferences.Editor prefeditor = sharedPreferences.edit();
            //if selection is mostPOp::5zen popular
            prefeditor.putString("selection", "popular");
            prefeditor.commit();
            selection = "popular";
            new Fetchmovie().execute(Mostpop);
            return true;
        }

       else if (id == R.id.sort_by_top_rated_id) {
            SharedPreferences.Editor prefeditor = sharedPreferences.edit();
            prefeditor.putString("selection", "top_rated");
            prefeditor.commit();
            selection = "top_rated";
            new Fetchmovie().execute(TopRate);
            return true;
        }

        else if (id == R.id.favorite_item_id) {
            SharedPreferences.Editor prefeditor = sharedPreferences.edit();
            prefeditor.putString("selection", "favorite");
            prefeditor.commit();
            selection = "favorite";
            loadFavorite();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void loadFavorite() {
        DBHelper dbHelper = new DBHelper(getActivity());
        Cursor cursor = dbHelper.gedata();
        posters = new ArrayList<>();
        poster_title = new ArrayList<>();
        release_date = new ArrayList<>();
        vote_average = new ArrayList<>();
        MovieId = new ArrayList<>();
        overView=new ArrayList<>();

        while (cursor.moveToNext()) {
            posters.add(cursor.getString(cursor.getColumnIndex(DBHelper.MOVIE_POSTER)));
            poster_title.add(cursor.getString(cursor.getColumnIndex(DBHelper.MOVIE_TITLE)));
            release_date.add(cursor.getString(cursor.getColumnIndex(DBHelper.MOVIE_RElEASE_DATE)));
            vote_average.add(cursor.getString(cursor.getColumnIndex(DBHelper.MOVIE_VOTE_AVERAGE)));
            MovieId.add(cursor.getString(cursor.getColumnIndex(DBHelper.MOVIE_ID)));
            columID.add(cursor.getInt(cursor.getColumnIndex(DBHelper.COLUMN_ID)));
            overView.add(cursor.getString(cursor.getColumnIndex(DBHelper.MOVIE_OVERVIEW)));
        }
        String url[] = new String[posters.size()];
        for (int i = 0; i < posters.size(); i++) {
            url[i] ="https://image.tmdb.org/t/p/w185" + posters.get(i);
           Toast.makeText(getActivity(), "posters : " + url[i], Toast.LENGTH_LONG).show();

        }
        GridViewAdapter  my = new GridViewAdapter(getActivity(), url);
        mGridView.setAdapter(my);
        dbHelper.close();
    }

    @Override
    public void onStart() {
        super.onStart();
        if (selection.equals("popular")) {
           Fetchmovie list = new Fetchmovie();
            list.execute(Mostpop);

        } else if (selection.equals("top_rated")) {
            Fetchmovie list = new Fetchmovie();
            list.execute(TopRate);

        } else if (selection.equals("favorite")) {
            loadFavorite();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container);
        progressLayout = (LinearLayout) view.findViewById(R.id.progress);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
        progressTV = (TextView) view.findViewById(R.id.progressTV);
        Toast.makeText(getActivity(), "heloooo", Toast.LENGTH_LONG).show();
        mGridView = (GridView) view.findViewById(R.id.gridview_id);

        mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                Intent intent = new Intent(getActivity(), DetailActivity.class).putExtra("posters", posters.get(position));
                intent.putExtra("poster_title", poster_title.get(position));
                intent.putExtra("release_date", release_date.get(position));
                intent.putExtra("vote_average", vote_average.get(position));
                intent.putExtra("overView", overView.get(position));
                intent.putExtra("MovieId", MovieId.get(position));
                ((Callback) getActivity()).onItemSelected(intent);
            }
        });


        return view;
    }
    public interface Callback {
        public void onItemSelected(Intent dateUri);
    }

    private void updateMovies(String sort_by) {
        if (Connection.isConnected(getActivity())) {
            Fetchmovie fetchmovie = new Fetchmovie();
            fetchmovie.execute(sort_by);
        } else {
            progressBar.setVisibility(View.GONE);
            progressTV.setText("Check Internet Connection");
        }
    }


    public class Fetchmovie extends AsyncTask<String, Void, String[]> {


        protected String[] doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String moviejosen = null;
            String[] l = null;
            try {

                ///////////////open connection////////////////////
                String baseUrl = params[0]; //"https://api.themoviedb.org/3/movie/popular?api_key=b0797d851c197292e1fb93002bcff3c1";
                URL url = new URL(baseUrl);
                urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("GET");
                urlConnection.connect();


                ///////////read the stream////////////////

                InputStream inputStream = urlConnection.getInputStream();

                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {

                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {

                    return null;
                }
                moviejosen = buffer.toString();
                l = getmovies(moviejosen);
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                }
            }
            return l;
        }

        protected void onPostExecute(String[] arrayOfString) {

            final GridViewAdapter gridViewAdapter = new GridViewAdapter(getActivity(), arrayOfString);

            mGridView.setAdapter(gridViewAdapter);

        }

    }

    /////////////convert the string to jsonObject/////////////

    private String[] getmovies(String moviejosen) {
        String[] urls = null;//to get result length
        posters.clear();
        poster_title.clear();
        vote_average.clear();
        overView.clear();
        MovieId.clear();
        try {
            JSONObject jsonObject = new JSONObject(moviejosen);
            JSONArray result = jsonObject.getJSONArray("results");
            urls = new String[result.length()];
            for (int i = 0; i < result.length(); i++) {


                ////////to get the json array objects//////////

                JSONObject m = result.getJSONObject(i);
                String path = m.getString("poster_path");
                String title = m.getString("original_title");
                String release = m.getString("release_date");
                String vote = m.getString("vote_average");
                String Oview = m.getString("overview");
                String Mid = m.getString("id");

                posters.add(path);
                poster_title.add(title);
                release_date.add(release);
                vote_average.add(vote);
                overView.add(Oview);
                MovieId.add(Mid);


                urls[i] = "https://image.tmdb.org/t/p/w185" + path;
                Log.e("my dataa dfdf", path);


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return urls;


    }
}






