package com.example.dora.movies;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

/**
 * Created by Dora on 8/31/2016.
 */
public class DBHelper extends SQLiteOpenHelper {

    String TAG = "Database Helper";
    public static String DBName = "favorite_DB";
    public static final int version = 1;
    public static final String TABLE_Favorites = "fav_movies";

    public static final String COLUMN_ID = "id";
    public static final String MOVIE_ID = "movie_id";
    public static final String MOVIE_POSTER = "poster";
    public static final String MOVIE_TITLE = "movie_title";
    public static final String MOVIE_RElEASE_DATE = "release_Date";
    public static final String MOVIE_VOTE_AVERAGE = "vote_average";
    public static final String MOVIE_OVERVIEW = "overview";
    public static String FAVORITE_SELECTION = "FAVORITE_SELECTION";


    private static final String DATABASE_CREATE = "create table "
            + TABLE_Favorites + "(" + COLUMN_ID
            + " integer primary key autoincrement, " + MOVIE_ID
            + " text unique, " + MOVIE_POSTER + " text, " + MOVIE_TITLE + " text , " + MOVIE_RElEASE_DATE
            + " text , " + MOVIE_VOTE_AVERAGE  +" text , "+ MOVIE_OVERVIEW
            + " text , "  + FAVORITE_SELECTION + " INTEGER );";

    Context context;

    public DBHelper(Context context) {
        super(context, DBName, null, version);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        Toast.makeText(context, "DataBase Upgraded", Toast.LENGTH_LONG).show();
        sqLiteDatabase.execSQL("Drop table if exists favoriteMovies");
        onCreate(sqLiteDatabase);
    }

    public void InsertData(ContentValues contentValues) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.insert(TABLE_Favorites, null, contentValues);
        sqLiteDatabase.close();
       // Toast.makeText(context, "Data Inserted", Toast.LENGTH_LONG).show();
    }


    public Cursor gedata() {

        SQLiteDatabase db = this.getReadableDatabase();

        String[] Columns = {COLUMN_ID, MOVIE_ID, MOVIE_POSTER, MOVIE_TITLE, MOVIE_RElEASE_DATE, MOVIE_VOTE_AVERAGE,MOVIE_OVERVIEW,
                FAVORITE_SELECTION};
//        String where = FAVORITE_SELECTION+"=? AND " + FAVORITE_SELECTION+"=?";
//        String []args = {"1","ssas"};
      //  String where = FAVORITE_SELECTION + "=?";
       // String[] args = {"1"};

        Cursor cursor = db.query(TABLE_Favorites, null, null, null, null, null, null);
        //  Log.e("Favour  data","fav"+cursor.getCount());
        return cursor;
    }
    public int updatePosters(String Currentposters, String Newposters) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MOVIE_POSTER, Newposters);
        String[] args = {Currentposters};

        int Count = db.update(TABLE_Favorites, contentValues, MOVIE_POSTER + "=?", args);

        return Count;

    }


}
