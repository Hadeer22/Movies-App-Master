package com.example.dora.movies;

/**
 * Created by Dora on 9/17/2016.
 */
public interface ActionCallback {
    public void actionCallback(MainFragment mainFragment);
}
