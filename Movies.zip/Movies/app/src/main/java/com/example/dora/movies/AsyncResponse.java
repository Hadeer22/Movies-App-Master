package com.example.dora.movies;

import java.util.List;

/**
 * Created by icosol_IT7x2R on 22/09/2016.
 */
public interface AsyncResponse {
    public void postExecuteTrailers(String data);
    public void  postExecuteReviews(String data2);
}
