package com.example.dora.movies;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dora on 9/13/2016.
 */
public class ReviewAsync extends AsyncTask<String, Void, String> {

    public AsyncResponse delegate = null;
    Context con;
    public ReviewAsync(Context con) {
        // this.trailersCallback = trailersCallback;
        this.con=con;
    }

    @Override

    protected String doInBackground(String... params) {

        if (params.length == 0) {
            return null;
        }



        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;

        String jsonStr = null;

        try {
            final String BASE_URL = "http://api.themoviedb.org/3/movie/"+params[0]+"/reviews";
            final String API_KEY_PARAM = "api_key";
            final String THEMOVIEDB_API_KEY = "b0797d851c197292e1fb93002bcff3c1";

            Uri builtUri = Uri.parse(BASE_URL).buildUpon()
                    .appendQueryParameter(API_KEY_PARAM, THEMOVIEDB_API_KEY)
                    .build();

            URL url = new URL(builtUri.toString());
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();
            if (inputStream == null) {
                return null;
            }
            reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line + "\n");
            }
            if (buffer.length() == 0) {
                return null;
            }
            jsonStr = buffer.toString();
        } catch (IOException e) {

            return null;
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {

                }
            }
        }

        return jsonStr;
    }


    protected void onPostExecute(String rev) {
        // call back to return trailers data to MainFragment
        // Toast.makeText(con,trailers,Toast.LENGTH_LONG).show();
        delegate.postExecuteReviews(rev);
        /*if (this.trailersCallback != null) {
            trailersCallback.postExecuteTrailers(trailers);*/
    }
}