package com.example.dora.movies;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
public class DetailFragment extends Fragment implements AsyncResponse {
    private TextView mPosterTitleView;
    private TextView mPoster_release_date;
    private TextView mPoster_vote_average;
    private TextView mOver_view;
    public static List<Trailers_Data> trailerList;
    DBHelper dbHelper = new DBHelper(getContext());
    public static String poster_string;
    public static String poster_title_string;
    public static String release_date_string;
    public static String vote_average_string;
    public static String overView_String;
    public static String Movie_ID_String;
    MainFragment mainFragment = new MainFragment();
    ImageButton imageButton;
    List<String> youtubelist;
    ListView trailersListView, reviewsListView;
    public static final String TAG = "Detail Fragment";
    ArrayAdapter<String> arrayAdapter;
    ArrayAdapter<String> arrayAdapter2;
    ArrayList<String>trailers;
    ArrayList<String>reviews;
    ArrayList<String>reviews2;



    ContentValues contentValues;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_detail, container, false);
        youtubelist=new ArrayList<>();

        trailersListView = (ListView) rootView.findViewById(R.id.trailersListV);
        reviewsListView = (ListView) rootView.findViewById(R.id.reviewsListV);

        trailers=new ArrayList<String>();
        reviews=new ArrayList<String>();


        arrayAdapter = new ArrayAdapter<String>(getActivity(),R.layout.trailer_list_item,R.id.trailer_text, trailers);
        arrayAdapter2 = new ArrayAdapter<String>(getActivity(),R.layout.review_list_item,R.id.review_text, reviews);






        trailersListView.setAdapter(arrayAdapter);
        reviewsListView.setAdapter(arrayAdapter2);





        View main = inflater.inflate(R.layout.activity_main, container, false);



       // Toast.makeText(getActivity().getApplicationContext(),"Send",Toast.LENGTH_LONG).show();
        /// modifications
        Intent intent = getActivity().getIntent();
        /////get the sent intent from the main activity//////
        if (main.findViewById(R.id.details_container) == null) {
            if (intent != null && intent.hasExtra("posters")) {
                poster_string = intent.getStringExtra("posters");
                ImageView imageView = (ImageView) rootView.findViewById(R.id.moviePoster_detail_id);
                Picasso.with(getActivity()).load("http://image.tmdb.org/t/p/w185" + poster_string).into(imageView);
            }
            if (intent != null && intent.hasExtra("poster_title")) {
                poster_title_string = intent.getStringExtra("poster_title");
                mPosterTitleView = (TextView) rootView.findViewById(R.id.detail_title_id);
                mPosterTitleView.setText(poster_title_string);
            }
            if (intent != null && intent.hasExtra("release_date")) {
                release_date_string = intent.getStringExtra("release_date");
                mPoster_release_date = (TextView) rootView.findViewById(R.id.release_date_id);
                mPoster_release_date.setText(release_date_string);
            }
            if (intent != null && intent.hasExtra("vote_average")) {
                vote_average_string = intent.getStringExtra("vote_average");
                mPoster_vote_average = (TextView) rootView.findViewById(R.id.vote_average_id);
                mPoster_vote_average.setText(vote_average_string);
            }
            if (intent != null && intent.hasExtra("overView")) {
                overView_String = intent.getStringExtra("overView");
                mOver_view = (TextView) rootView.findViewById(R.id.overview_id);
                mOver_view.setText(overView_String);
            }
            if (intent != null && intent.hasExtra("MovieId")) {
                Movie_ID_String = intent.getStringExtra("MovieId");

            }
        }
        else{
            poster_string = getArguments().getString("posters");
            ImageView imageView = (ImageView) rootView.findViewById(R.id.moviePoster_detail_id);
            Picasso.with(getActivity()).load("http://image.tmdb.org/t/p/w185" + poster_string).into(imageView);
            poster_title_string = getArguments().getString("poster_title");
            mPosterTitleView = (TextView) rootView.findViewById(R.id.detail_title_id);
            mPosterTitleView.setText(poster_title_string);
            release_date_string = getArguments().getString("release_date");
            mPoster_release_date = (TextView) rootView.findViewById(R.id.release_date_id);
            mPoster_release_date.setText(release_date_string);
            vote_average_string = getArguments().getString("vote_average");
            mPoster_vote_average = (TextView) rootView.findViewById(R.id.vote_average_id);
            mPoster_vote_average.setText(vote_average_string);
            overView_String = getArguments().getString("overView");
            mOver_view = (TextView) rootView.findViewById(R.id.overview_id);
            mOver_view.setText(overView_String);
            Movie_ID_String = getArguments().getString("MovieId");
        }
        TrailerAsync t= new TrailerAsync(getActivity().getApplicationContext());
        t.delegate=this;
        t.execute(Movie_ID_String);

        trailersListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                startPlayingIntent(youtubelist.get(position));
                //  Toast.makeText(getActivity().getApplicationContext(),"Clicked",Toast.LENGTH_LONG).show();



            }
        });


        addTOFavorite(rootView);
        return rootView;
    }


    @Override
    public void  postExecuteReviews(String reviewDataList) {
        try {

           // Toast.makeText(getActivity().getApplicationContext(),reviewDataList,Toast.LENGTH_LONG).show();

            JSONObject reviewJson = new JSONObject(reviewDataList);
            JSONArray reviewArray = reviewJson.getJSONArray("results");
            List<Review_data> results2 = new ArrayList<>();
            for (int i = 0; i < reviewArray.length(); i++) {
                JSONObject reviewObject = reviewArray.getJSONObject(i);
                results2.add(new Review_data(reviewObject));
                reviews.add(results2.get(i).getContent());
                //reviews2.add(results.get(i).getAuthor());

            }
            arrayAdapter2.notifyDataSetChanged();


        }
        catch (JSONException e) {
            e.printStackTrace();
        }



    }
    public void postExecuteTrailers(String trailerDataList){
        try {
            JSONObject trailerJson = new JSONObject(trailerDataList);
            JSONArray trailerArray = trailerJson.getJSONArray("results");
            List<Trailers_Data> results = new ArrayList<>();
            for (int i = 0; i < trailerArray.length(); i++) {
                JSONObject trailerObject = trailerArray.getJSONObject(i);
                results.add(new Trailers_Data(trailerObject));
                trailers.add(results.get(i).getName());
                youtubelist.add(results.get(i).getKey());
            }



            arrayAdapter.notifyDataSetChanged();
            ReviewAsync R=new ReviewAsync(getActivity().getApplicationContext());
            R.delegate=this;
            R.execute(Movie_ID_String);
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void startPlayingIntent(String trailer) {
        String url = "https://www.youtube.com/watch?v=" + trailer;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    public void addTOFavorite(View rootView) {
        Bundle arguments = getArguments();
        final ImageButton iMbtn = (ImageButton) rootView.findViewById(R.id.favBtn_ID);
        iMbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                iMbtn.setImageResource(R.mipmap.ic_favorite_black_24dp);
                ContentValues contentValues = new ContentValues();
                contentValues.put(DBHelper.MOVIE_POSTER, poster_string);
                contentValues.put(DBHelper.MOVIE_TITLE, poster_title_string);
                contentValues.put(DBHelper.MOVIE_RElEASE_DATE, release_date_string);
                contentValues.put(DBHelper.MOVIE_VOTE_AVERAGE, vote_average_string);
                contentValues.put(DBHelper.MOVIE_ID, Movie_ID_String);
                DBHelper dbHelper = new DBHelper(getActivity());
                dbHelper.InsertData(contentValues);
                Toast.makeText(getActivity(), "Added To Favorites", Toast.LENGTH_LONG).show();
               // Log.e("my dataa dfdf", poster_title_string);

            }
        });
    }

}