package com.example.dora.movies;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements MainFragment.Callback{

    private boolean mTwoPane;
    private static final String DETAILFRAGMENT_TAG = "DFTAG";
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        if(savedInstanceState==null){
            setContentView(R.layout.activity_main);
            if (findViewById(R.id.details_container) != null) {
                mTwoPane = true;
            } else {
                mTwoPane = false;
            }
        }
    }
    @Override
    public void onItemSelected(Intent intent) {
        DetailFragment myfrag = new DetailFragment();
        if (mTwoPane == true) {
            myfrag.setArguments(intent.getExtras());
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.details_container, myfrag, DETAILFRAGMENT_TAG)
                    .commit();
        } else {

            startActivity(intent);
        }
    }
}

