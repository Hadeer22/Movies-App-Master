package com.example.dora.movies;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Dora on 9/10/2016.
 */

public class Review_data {
    private String id;
    private String author;
    private String content;
    private String url;

    public Review_data(JSONObject reviewObject) throws JSONException {
        this.id = reviewObject.getString("id");
        this.author = reviewObject.getString("author");
        this.content = reviewObject.getString("content");
        this.url = reviewObject.getString("url");
    }

    public String getUrl() {
        return url;
    }

    public String getAuthor() {
        return author;
    }

    public String getContent() {
        return content;
    }

    public String getId() {
        return id;
    }
}